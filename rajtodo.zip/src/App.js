import Todolist from './components/Todolist'

import './App.css'

const App = () => <Todolist />
export default App